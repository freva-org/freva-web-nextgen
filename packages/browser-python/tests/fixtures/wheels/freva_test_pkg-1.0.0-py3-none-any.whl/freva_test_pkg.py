"""A fixture package. Installed by browser-tests/micropip.mjs and nothing else."""

__version__ = "1.0.0"


def greet(name="world"):
    """Return something the test can compare exactly."""
    return f"hello {name} from an installed wheel"


def add(a, b):
    """Proof that installed code actually executes, not merely imports."""
    return a + b
